RUN NPM INSTALL IN FRONTEND AND BACKEND FOLDER

RUN node server.js from backend folder
RUN npm start from frontend folder

CREATE DB AND SET DB CREDENTIALS

BYDEFAULT USER WILL CREATE WITH user type change type to "admin" from db and login again for add product

SEE VIDEO UPLOADED ON SAME GITHUB REPOSITORY