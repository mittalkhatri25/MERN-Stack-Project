const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
const PORT = 5000;

let SECRET_KEY = "TEST@123";

app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "http://localhost:3000");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept"
  );
  next();
});

const authenticateJWT = (req, res, next) => {
  const token = req.header('Authorization')?.split(' ')[1]; 

  if (!token) {
      return res.sendStatus(403);
  }

  jwt.verify(token, SECRET_KEY, (err, user) => {
      if (err) {
          return res.sendStatus(403); 
      }
      req.user = user; 
      next();
  });
};

app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/mernfood', { useNewUrlParser: true, useUnifiedTopology: true });

const User = mongoose.model('users', new mongoose.Schema({
  name: String,
  mobile: String,
  password: String,
  role: { type: String, enum: ['user', 'admin'], default: 'user' },
}));

const FoodItem = mongoose.model('food_items', new mongoose.Schema({
  name: String,
  description: String,
  price: String,
}));

const Order = mongoose.model('orders', new mongoose.Schema({
  user_id: String,
  total : String,
  order_number : String
}));

const OrderItem = mongoose.model('order_items', new mongoose.Schema({
  order_id: String,
  food_item_id : String,
  price : String,
  qty : String,
  total : String,
}));

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});


app.post('/user', async (req, res) => {
  const name = req.body.name;
  const mobile = req.body.mobile;
  const password = req.body.password;
  const hashedPassword = await bcrypt.hash(password, 10);
  const user = new User({name,mobile,password : hashedPassword});
  await user.save();
  res.json(user);
});

app.post('/attempt-login',async (req,res) => {
  const mobile = req.body.mobile;
  const password = req.body.password;
  let user = await User.findOne({ mobile });
  if (!user){
    const name = "";
    const hashedPassword = await bcrypt.hash(password, 10);
    user = new User({name,mobile,password : hashedPassword});
    await user.save();
  }
  const token = jwt.sign({ userId: user._id, role: user.role }, SECRET_KEY, {
    expiresIn: '24h',
  });
  res.json({ token ,role : user.role});
})

app.get('/admin/get-products',async (req,res) => {
  let products = await FoodItem.find({});
  res.json({products});
})

app.post('/admin/save-product',async (req,res) => {
  let product = new FoodItem(req.body);
  await product.save();
  res.json({success:true,product});
})

const generateOrderNumber = () => {
  const timestamp = Date.now(); 
  const randomNum = Math.floor(Math.random() * 100000);
  return `ORD-${timestamp}-${randomNum}`;
}

app.post('/placeorder',authenticateJWT,async (req,res) =>{
  let items = req.body.items;
  let Total = items.map(item => item.itemTotal).reduce((partialSum, a) => partialSum + a, 0);
  let orderNumber = generateOrderNumber();
  const order = new Order({user_id : req.user.userId,total : Total,order_number: orderNumber});
  await order.save();
  let orderID = order._id;
  items.forEach(async (item) => {
    let itemSave = new OrderItem({
      order_id: orderID,
      food_item_id : item._id,
      price : item.price,
      qty : item.quantity,
      total : item.itemTotal,
    });
    await itemSave.save();
  })
  res.json({success : true,order_number : order.order_number });
})

app.get('/user/order-history',authenticateJWT,async (req,res) =>{
  const orders = await Order.find({ user_id: req.user.userId });
  res.json({success : true,orders : orders});
})