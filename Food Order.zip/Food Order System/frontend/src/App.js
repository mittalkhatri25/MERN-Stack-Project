// src/App.js
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Header from './Pages/Components/Header';
import Footer from './Pages/Components/Footer';
import Home from './Pages/Home';
import About from './Pages/About';
import Login from './Pages/Auth/Login';
import Register from './Pages/Auth/Register';
import AdminDashboard from './Pages/Admin/Dashboard';
import UserDashboard from './Pages/User/Dashboard';
import { Navigate, Outlet } from 'react-router-dom';
import { useState } from 'react';
import { useEffect } from 'react';
import { UserProvider } from './Pages/Components/UserContext';
import AdminProductList from './Pages/Admin/Products/List';
import UserOrder from './Pages/User/Order';
import { CartProvider } from "react-use-cart";
import Cart from './Pages/User/Cart';
import ThankyouPage from './Pages/User/Thankyou';
import UserOrderHistory from './Pages/User/OrderHistory';

import 'bootstrap/dist/css/bootstrap.min.css';

import { createBrowserHistory } from 'history';
const history = createBrowserHistory();


const ProtectedRoute = ({ role }) => {
  const token = localStorage.getItem('token');
  const userRole = token ? JSON.parse(atob(token.split('.')[1])).role : null;

  if (!token) {
    return <Navigate to="/login" replace />;
  }

  if (role && userRole !== role) {
    return <Navigate to="/unauthorized" replace />;
  }

  return <Outlet />;
};

const App = () => {
  return (
      <Router history={history}>
        <CartProvider>
          <UserProvider>
          <div>
            <Header />
            <main>
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />
                <Route path="/cart" element={<Cart />} />
                <Route path="/thankyou" element={<ThankyouPage />} />
                <Route path='/admin' element={<ProtectedRoute role="admin" />}>
                  <Route index element={<AdminProductList />} />
                  <Route path='products' element={<AdminProductList />} />
                </Route>
                <Route path='/user' element={<ProtectedRoute role="user" />}>
                  <Route index element={<UserOrder />} />
                  <Route path="order" element={<UserOrder />} />
                  <Route path="order_history" element={<UserOrderHistory />} />
                </Route>
              </Routes>
            </main>
            <Footer />
          </div>
          </UserProvider>
        </CartProvider>
      </Router>
  );
}

export default App;