const AdminDashboard = () =>  {
    return (
        <div className='container container-fluid'>
            ADMIN DASHBOARD
        </div>
    );
}

export default AdminDashboard;