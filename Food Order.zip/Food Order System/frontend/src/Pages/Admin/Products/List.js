import { useEffect,useState } from 'react';
import axiosInstance from '../../../axios';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Form from 'react-bootstrap/Form';
import Table from 'react-bootstrap/Table';



const AdminProductList = () =>  {
    let [addProduct,setAddProduct] = useState({
        name : '',
        description : '',
        price : '',
    });

    let [products,setProducts] = useState([]);
    let [addProductVisible,setAddProductVisible] = useState(false);

    const getProducts = async () => {
        const response = await axiosInstance.get('/admin/get-products');
        setProducts(response.data.products);
    };

    const handleClose = () => {
        setAddProductVisible(false);
        setAddProduct({
            name : '',
            description : '',
            price : '',
        });
    }

    const saveProduct = async (e) => {
        e.preventDefault();
        if(addProduct.name == "" || addProduct.description == "" || addProduct.price == ""){
            alert('validation error');
            return;
        }

        let addProductResponse = await axiosInstance.post("/admin/save-product",{...addProduct});
        if(addProductResponse.data.success){
            await getProducts();
        }
        setAddProductVisible(false)
    }

    useEffect(() => {
        getProducts();
    },[])
    return (
        <>
            <Modal show={addProductVisible} onHide={handleClose}>
                <Modal.Header closeButton>
                <Modal.Title>ADD PRODUCT</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form.Group className="mb-3">
                        <Form.Label>Name</Form.Label>
                        <Form.Control value={addProduct.name} onChange={(e) => setAddProduct({...addProduct,name : e.target.value})}></Form.Control>
                    </Form.Group>
                    <Form.Group className="mb-3">
                        <Form.Label>Description</Form.Label>
                        <Form.Control as="textarea" value={addProduct.description} onChange={(e) => setAddProduct({...addProduct,description : e.target.value})}></Form.Control>
                    </Form.Group>
                    <Form.Group className="mb-3">
                        <Form.Label>Price</Form.Label>
                        <Form.Control type='number' value={addProduct.price} onChange={(e) => setAddProduct({...addProduct,price : e.target.value})}></Form.Control>
                    </Form.Group>
                </Modal.Body>
                <Modal.Footer>
                <Button variant="secondary" onClick={handleClose}>
                    Close
                </Button>
                <Button variant="primary" onClick={(e) => saveProduct(e)}>
                    Save Changes
                </Button>
                </Modal.Footer>
            </Modal>
            <div className='container container-fluid'>
                <Button onClick={(e) => setAddProductVisible(true)} > Add Product </Button>
            </div>
            <Table striped bordered hover>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Price</th>
                    </tr>
                </thead>
                <tbody>
                    {products.length > 0 ? (
                        <>
                            {products.map((product) => (
                                <tr>
                                    <td>{product._id}</td>
                                    <td>{product.name}</td>
                                    <td>{product.description}</td>
                                    <td>{product.price}</td>
                                </tr>
                            ))}
                        </>
                    ) : (
                        <>
                        <tr>
                            <td colSpan={4}>No Data</td>
                        </tr>
                        </>
                    )}
                </tbody>
            </Table>
        </>
    );
}

export default AdminProductList;