import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import { useState } from 'react';
import axiosInstance from '../../axios';
import { useNavigate } from 'react-router-dom';
import { UserContext } from '../Components/UserContext';
import { useContext } from 'react';


const Login = () =>  {
    const { user,setToken } = useContext(UserContext);

    const [mobile,setMobile] = useState("");
    const [password,setPassword] = useState("");
    const navigate = useNavigate();

    const attemptLogin = async (e) => {
        e.preventDefault();
        let response = await axiosInstance.post('/attempt-login',{mobile,password});
        await setToken(response.data.token);
        if(response.data.role == 'admin'){
            navigate('/admin');
            return false;
        }
        navigate('/user');
    }
    return (
        <div className='container container-fluid'>
            <h3>Login Page</h3>
            <Form onSubmit={attemptLogin}>
                <Form.Group className="mb-3" >
                    <Form.Label>Mobile</Form.Label>
                    <Form.Control required value={mobile} onChange={(e) => setMobile(e.target.value)}  placeholder="Enter mobile" />
                </Form.Group>

                <Form.Group className="mb-3">
                    <Form.Label>Password</Form.Label>
                    <Form.Control required value={password} onChange={(e) => setPassword(e.target.value)} type="password" placeholder="Password" />
                </Form.Group>
                <Button variant="primary" type="submit">
                    LogIn
                </Button>
            </Form>
        </div>
    );
}

export default Login;