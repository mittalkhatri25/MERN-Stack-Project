import { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import axiosInstance from '../../axios';
import { useNavigate } from 'react-router-dom';


const Register = () =>  {

    const [name,setName] = useState("");
    const [mobile,setMobile] = useState("");
    const [password,setPassword] = useState("");
    const navigate = useNavigate();

    const submitRegister = async (e) => {
        e.preventDefault();
        let response = await axiosInstance.post('/user',{name,mobile,password})
        navigate('/login')
    }

  return (
    <div className='container container-fluid'>
        <h3>Register Page</h3>
        <Form onSubmit={submitRegister}>
            <Form.Group className="mb-3" >
                <Form.Label>Name</Form.Label>
                <Form.Control required value={name} onChange={(e) => setName(e.target.value)} placeholder="Name" />
            </Form.Group>

            <Form.Group className="mb-3">
                <Form.Label>Mobile</Form.Label>
                <Form.Control required value={mobile} onChange={(e) => setMobile(e.target.value)}  placeholder="Enter mobile" />
            </Form.Group>

            <Form.Group className="mb-3">
                <Form.Label>Password</Form.Label>
                <Form.Control required value={password} onChange={(e) => setPassword(e.target.value)} type="password" placeholder="Password" />
            </Form.Group>
            <Button variant="primary" type="submit">
                Register
            </Button>
        </Form>
    </div>
  );
}

export default Register;