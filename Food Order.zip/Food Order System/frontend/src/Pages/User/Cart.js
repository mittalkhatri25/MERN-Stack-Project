import { useCart } from "react-use-cart";    
import Table from "react-bootstrap/esm/Table";
import Button from "react-bootstrap/Button";
import axios from "../../axios";
import { useNavigate } from "react-router-dom";
const Cart = () =>  {
    const navigate = useNavigate();
    const { items,emptyCart } = useCart();
    const placeOrder = async () => {
        let response = await axios.post("/placeorder",{items});
        if(response.data.success){
            navigate('/thankyou?order_number='+response.data.order_number)
            emptyCart();
        }
    }
    return (
        <div className='container container-fluid'>
            {items.length > 0 ? (
                <>
                    <Table striped>
                        <thead>
                            <tr>
                                <th>Sr</th>
                                <th>Name</th>
                                <th>Price</th>
                                <th>Qty</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            {items.map((item,idx) => (
                                <tr>
                                    <td>{idx + 1}</td>
                                    <td>{item.name}</td>
                                    <td>Rs. {item.price}</td>
                                    <td>{item.quantity}</td>
                                    <td>Rs. {item.price * item.quantity}</td>
                                </tr>
                            ))}
                        </tbody>
                    </Table>
                    <center>
                        <Button onClick={placeOrder}>PLACE ORDER</Button>
                    </center>
                </>
            ) : (
                <>NO PRODUCT IN CART</>
            )}
        </div>
    );
}
export default Cart;