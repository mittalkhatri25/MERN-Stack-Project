const UserDashboard = () =>  {
    return (
        <div className='container container-fluid'>
            USER DASHBOARD
        </div>
    );
}

export default UserDashboard;