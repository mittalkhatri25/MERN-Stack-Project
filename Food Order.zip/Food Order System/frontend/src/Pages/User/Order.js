import { useEffect,useState } from 'react';
import axiosInstance from '../../axios';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import { useCart } from "react-use-cart";


const UserOrder = () =>  {
    let [products,setProducts] = useState([]);

    const { addItem,getItem,inCart,removeItem } = useCart();

    const chunks = (array, chunkSize) => {
        const result = [];
        for (let i = 0; i < array.length; i += chunkSize) {
          const chunk = array.slice(i, i + chunkSize);
          result.push(chunk);
        }
        console.log(result,'result')
        return result;
    }

    const getProducts = async () => {
        const response = await axiosInstance.get('/admin/get-products');
        setProducts(chunks(response.data.products,2));
    };

    const addToCart = (product) => {
        product['id'] = product._id;
        addItem(product, 1);
    }

    useEffect(() => {
        getProducts();
    },[])
    return (
        <>
            <div className='container container-fluid mt-5'>
                {products.map(products => (
                    <Row>
                        {products.map(product => (
                            <Col>
                                <Card className='mb-5'>
                                    <Card.Body>
                                        <Card.Title>{product.name}</Card.Title>
                                        <Card.Text>
                                            {product.description}
                                        </Card.Text>
                                        {inCart(product._id) ? (
                                            <Button variant="primary" onClick={(e) => removeItem(product._id)}>REMOVE</Button>
                                        ) : (
                                            <Button variant="primary" onClick={(e) => addToCart(product)}>ADD TO CART</Button>
                                        )}
                                    </Card.Body>
                                </Card>
                            </Col>
                        ))}
                    </Row>
                ))}
            </div>
        </>
    );
}

export default UserOrder;