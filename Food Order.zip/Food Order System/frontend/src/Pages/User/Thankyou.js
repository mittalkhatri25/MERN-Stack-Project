import { useState,useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useLocation } from 'react-router-dom';


const ThankyouPage = () =>  {
    const [countdownTime, setCountdownTime] = useState(5);
    const navigate = useNavigate();
    const location = useLocation();
    const queryParams = new URLSearchParams(location.search);
    const order_number = queryParams.get('order_number');


    useEffect(() => {
      if (countdownTime === 0) {
        navigate('/user/order');
      }
  
      const interval = setInterval(() => {
        setCountdownTime(prevTime => prevTime - 1);
      }, 1000);
  
      return () => clearInterval(interval);
    }, [countdownTime, navigate]);

    return (
        <div className='container container-fluid mt-5'>
            <center>
                <p>Thank you for your purchase.</p>
                <p>Your Order number is <code>{order_number}</code>.</p>
                <p>You will Redirect to Main page in {countdownTime} second{countdownTime > 1 ? 's':''}.</p>
            </center>
        </div>
    );
}

export default ThankyouPage;