import { useState,useEffect } from "react";
import Table from 'react-bootstrap/Table';
import axiosInstance from "../../axios";
import Nav from 'react-bootstrap/Nav';
import { Link } from 'react-router-dom';


const OrderHistory = () =>  {
    const [orders,setOrders] = useState([]);

    const getOrders = async () => {
        let response = await axiosInstance.get('/user/order-history');
        if(response.data.success){
            setOrders(response.data.orders);
        }
    }

    useEffect(() => {
        getOrders();
    },[]);

    return (
        <div className='container container-fluid mt-5'>
            <Table striped>
                <thead>
                    <tr>
                        <th>ORDER NUMBER</th>
                        <th>ORDER AMOUNT</th>
                    </tr>
                </thead>
                <tbody>
                    {orders.length > 0 ? (
                        <>
                            {orders.map((order) => (
                                <tr>
                                    <td>{order.order_number}</td>
                                    <td>{order.total}</td>
                                </tr>
                            ))}
                        </>
                    ) : (
                        <>
                        <tr>
                            <td colSpan={2}>NO ORDERS</td>
                        </tr>
                        </>
                    )}
                </tbody>
            </Table>
        </div>
    );
}

export default OrderHistory;