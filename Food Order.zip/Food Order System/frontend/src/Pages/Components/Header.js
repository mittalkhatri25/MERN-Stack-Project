import Button from 'react-bootstrap/Button';
import Container from 'react-bootstrap/Container';
import Form from 'react-bootstrap/Form';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import { Link } from 'react-router-dom';
import { UserContext } from './UserContext';
import { useContext } from 'react';
import { useCart } from "react-use-cart";    
import Badge from 'react-bootstrap/Badge';

const Header = () => {
  const { items } = useCart();
  const { user, logout } = useContext(UserContext);
  return (
    <Navbar expand="lg" className="bg-body-tertiary">
      <Container fluid>
        <Navbar.Brand href="#">FOOD ORDER SYSTEM</Navbar.Brand>
        <Navbar.Toggle aria-controls="navbarScroll" />
        <Navbar.Collapse id="navbarScroll">
          <Nav
            className="me-auto my-2 my-lg-0"
            style={{ maxHeight: '100px' }}
            navbarScroll
          >
            {user ? (
              <>
                {user.role == 'user' ? (
                  <>
                    <Nav.Link as={Link} to="/user/order">ORDER NOW</Nav.Link>
                    <Nav.Link as={Link} to="/user/order_history">ORDER HISTORY</Nav.Link>
                    <Button as={Link} to="/cart" variant="link">
                      Cart <Badge bg="secondary">{items.length}</Badge>
                      <span className="visually-hidden">Cart</span>
                    </Button>
                  </>
                ) : (
                  <>
                    <Nav.Link as={Link} to="/admin">Home</Nav.Link>
                    <Nav.Link as={Link} to="/admin/products">Products</Nav.Link>
                  </>
                )}
                <Nav.Link as={Link} onClick={logout}>Logout</Nav.Link>
              </>
            ) : (
              <>
              <Nav.Link as={Link} to="/login">Login</Nav.Link>
              <Nav.Link as={Link} to="/register">Register</Nav.Link>
              </>
            )}
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default Header;