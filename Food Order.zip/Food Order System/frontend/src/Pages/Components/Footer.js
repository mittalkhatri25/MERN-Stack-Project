import React from 'react';

const Footer = () => {
  return (
    <div class="container">
        <footer class="py-3 my-4 fixed-bottom">
        <p class="text-center text-muted">&copy; {new Date().getFullYear()} FOOD ORDER SYSTEM</p>
      </footer>
    </div>
  );
}

export default Footer;
