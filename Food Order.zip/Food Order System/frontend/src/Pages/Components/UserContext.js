import React, { createContext, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

export const UserContext = createContext();

export const UserProvider = ({ children }) => {

  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    let token = localStorage.getItem('token');
    if (token) {
      const decodedUser = decodeToken(token);
      setUser(decodedUser);
    }
  }, []);

  const setToken = async (token) => {
    localStorage.setItem('token',token);
    if (token) {
      const decodedUser = decodeToken(token);
      setUser(decodedUser);
    }
  }

  const decodeToken = (token) => {
    const payload = token.split('.')[1];
    return JSON.parse(atob(payload));
  };

  const logout = () => {
    localStorage.removeItem('token');
    navigate('/login');
    window.location.href = window.location.href;
  };

  return (
    <UserContext.Provider value={{ user, setUser, logout,setToken }}>
      {children}
    </UserContext.Provider>
  );
};
